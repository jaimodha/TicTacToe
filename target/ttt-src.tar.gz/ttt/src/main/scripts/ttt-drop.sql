drop table played_games;
drop table saved_games;
drop table bord_entries;
drop table Games;
drop trigger testref on GamePlayers;
drop function insertdata();
drop table authorities;
drop table GamePlayers;

drop sequence hibernate_sequence; 